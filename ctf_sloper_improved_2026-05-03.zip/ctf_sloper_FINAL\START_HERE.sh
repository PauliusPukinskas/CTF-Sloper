#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "======================================================"
echo "  CTF SLOPER FINAL"
echo "======================================================"
# Keep startup offline-friendly: only install requirements if imports are missing.
set +e
python3 - <<'PY'
missing=[]
mods={"fastapi":"fastapi","uvicorn":"uvicorn","multipart":"python-multipart","PIL":"Pillow","numpy":"numpy","requests":"requests"}
for mod,pkg in mods.items():
    try:
        __import__(mod)
    except Exception:
        missing.append(pkg)
if missing:
    print("[CTF SLOPER] Missing Python packages:", ", ".join(missing))
    raise SystemExit(2)
raise SystemExit(0)
PY
check_status=$?
set -e
if [ "$check_status" = "2" ]; then
  echo "[CTF SLOPER] Installing requirements..."
  python3 -m pip install --user -r requirements.txt
fi
echo ""
echo "Open: http://127.0.0.1:7860"
python3 app.py
