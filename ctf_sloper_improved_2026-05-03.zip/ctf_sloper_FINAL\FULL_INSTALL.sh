#!/usr/bin/env bash
set -e
echo "[CTF SLOPER] Python syntax self-check..."
timeout 45 python3 -m py_compile app.py || { echo "[CTF SLOPER] app.py syntax error"; exit 1; }
echo "[CTF SLOPER] app.py syntax OK."
cd "$(dirname "$0")"
bash INSTALL_ALL_TOOLS_ONE_COMMAND.sh
