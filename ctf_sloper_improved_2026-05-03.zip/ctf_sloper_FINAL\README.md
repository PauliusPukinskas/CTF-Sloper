# CTF SLOPER FINAL

Local browser-based CTF solving workbench for file challenges: stego, misc,
reversing, forensics, crypto, PCAP, archives, images, binaries, documents,
audio, databases and generated artifacts.

No OSINT or live-target web workflow is run by default.

## Start

```bash
cd ~/Downloads
unzip ctf_sloper_latest.zip
cd ctf_sloper_FINAL
bash START_HERE.sh
```

Open:

```text
http://127.0.0.1:7860
```

## Final Update

This build preserves the v104 solver base and adds a final tournament workflow
layer in `sloper_v72/final_engine.py`.

- Added final text workflows for mixed-delimiter binary, continuous bit offsets,
  numeric byte streams, A1Z26, Polybius, case bits, space/tab bits, every-nth
  word/character routes, keyboard shifts, UUencode and bounded Brainfuck.
- Added archive workflow channels for ZIP/TAR comments, per-file comments,
  filename order/stem/first-char/last-char channels, size/mtime/permission byte
  channels and embedded magic offset manifests.
- Added PCAP workflow artifacts for DNS labels/TXT, HTTP payloads, compressed
  HTTP bodies, payload strings and IP-ID byte/bit channels.
- Added project-level final multi-file workflows: natural/reverse/mtime concat,
  filename/stem/size channels, pair XOR and AB/BA interleave.
- Added bounded recursive "onion" peeling for archive/compression/base64/reverse
  chains, with manifests and last-payload previews instead of endless recursion.
- Added safe archive-child handling so gzip-wrapped disk/binary children create
  strings/OpenXML/carving evidence without entering noisy recursive decoders.
- Added a fast binary/reversing route for ELF/PE/opaque files: strings, static
  binary summaries, stack/array transform artifacts and semantic string previews.
- Added image color/manual-review artifacts: channel streams, hue/brightness
  sorted streams, alpha/transparent hints and a visual review sheet.
- Added artifact-body promotion for high-signal decoded/extracted outputs: if
  the task states the wrapper format and an artifact contains the answer body,
  the wrapped candidate is promoted near the top with source evidence.
- Added `final_open_queue`, `final_workflow_map`, `unconfirmed_strict_flags`
  and stronger artifact hub grouping so useful visual and transform artifacts
  stay near the top even when no final answer is promoted.
- Removed the visible Global AI workflow from the UI. The main workspace is:
  Brief, Open First, Flags, Artifacts, Transforms, Files, Health, Logs.
- Stop Project remains available and writes partial reports at safe boundaries.

## How To Use During A CTF

1. Create a project and upload all challenge files at once.
2. Open **Brief** for status and workflow lanes.
3. Open **Open First** before browsing raw artifacts. These are ranked by
   evidence and manual usefulness.
4. Check **Flags** for strict final flags, unconfirmed strict-looking flags,
   bare `{...}` fragments, leetspeak and wrapper candidates.
5. Use **Transforms** and **Files** to open/download every generated child file.
6. Use **Health** if a solver failed or was skipped.
7. Use **Stop project** if a task is running too long; existing artifacts remain.

## Architecture

- `app.py` is intentionally small and only boots the modular wrapper.
- `sloper_legacy.py` keeps the old monolith for compatibility.
- `sloper_v72/bootstrap.py` installs modular solvers and endpoints.
- `sloper_v72/final_engine.py` is the final evidence/workflow layer.
- `static/index.html` is the local browser UI.

## Pattern Sources

The final pass indexed a large public CTF repository as pattern signal
(`https://github.com/ShundaZhang/CTF`) and the existing Cyber Sprint/audit
patterns. Public/private challenge answers are not hardcoded.

## Checks

Development checks used before packaging:

```bash
python -m py_compile app.py sloper_legacy.py
python -m compileall -q sloper_v72
node --check static/index.check.js
```

The release ZIP is clean: benchmark folders and development scripts are not
included in the packaged app.
