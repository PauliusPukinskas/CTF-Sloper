
"""CTF SLOPER v72 bootstrap.

Loads legacy app, installs v72 wrappers/endpoints, and exposes the legacy FastAPI app.
"""
from __future__ import annotations
import importlib
import mimetypes
from pathlib import Path
from .health import AGENT_HEALTH, agent_crash, install_health_endpoint
from .hidden_bits import decode_zero_width, zero_width_whitespace_agent, write_artifact, scan_flags
from .artifact_hub import compact_hub

def install(mod):
    mod.SL72_AGENT_HEALTH = AGENT_HEALTH
    mod.sl72_agent_crash = agent_crash

    install_health_endpoint(mod.app)

    old_zero = getattr(mod, "sl43_zero_width_decode", None)
    def sl43_zero_width_decode(*args, **kwargs):
        try:
            if args and isinstance(args[0], dict):
                report = args[0]
                root = args[1] if len(args) > 1 else Path(".")
                data = args[2] if len(args) > 2 else ""
                text = data.decode("utf-8", "ignore") if isinstance(data, bytes) else str(data)
                res = decode_zero_width(text)
                if res:
                    art = write_artifact(mod, root, report, "zero_width_decode_candidates.json", mod.json.dumps(res, indent=2, ensure_ascii=False), "sloper72_zero_width_decode", 430, "Compatibility zero-width decode artifact.")
                    for item in res[:20]:
                        scan_flags(mod, report, item.get("text", ""), "SLOPER v72 zero-width compat", art.get("path") if art else None, 420)
                return res
            if old_zero:
                return old_zero(*args, **kwargs)
            return decode_zero_width(args[0] if args else kwargs.get("text", ""))
        except Exception as e:
            agent_crash("sl43_zero_width_decode wrapper", e, args[0] if args and isinstance(args[0], dict) else None)
            return []
    mod.sl43_zero_width_decode = sl43_zero_width_decode

    old_chain = getattr(mod, "sl43_decode_chain_agent", None)
    def sl43_decode_chain_agent(*args, **kwargs):
        try:
            if old_chain:
                old_res = old_chain(*args, **kwargs)
            else:
                old_res = []
        except Exception as e:
            agent_crash("legacy sl43_decode_chain_agent", e, args[0] if args and isinstance(args[0], dict) else None)
            old_res = []
        try:
            if args and isinstance(args[0], dict):
                report = args[0]
                root = args[1] if len(args) > 1 else Path(".")
                data = args[2] if len(args) > 2 else b""
                new_res = zero_width_whitespace_agent(mod, report, root, data)
                if old_res and isinstance(old_res, list):
                    return old_res + new_res
                return new_res or old_res
        except Exception as e:
            agent_crash("v72 sl43_decode_chain_agent wrapper", e, args[0] if args and isinstance(args[0], dict) else None)
        return old_res
    mod.sl43_decode_chain_agent = sl43_decode_chain_agent

    old_run = getattr(mod, "sl_run_agents", None)
    def sl_run_agents(report, root, data):
        arts = []
        if old_run:
            try:
                old_arts = old_run(report, root, data)
                if old_arts:
                    arts += old_arts
            except Exception as e:
                agent_crash("legacy sl_run_agents", e, report)
        try:
            new_arts = zero_width_whitespace_agent(mod, report, root, data)
            if new_arts:
                arts += new_arts
        except Exception as e:
            agent_crash("v72 zero_width_whitespace_agent", e, report)
        try:
            if hasattr(mod, "sl_finalize_report"):
                mod.sl_finalize_report(report)
        except Exception as e:
            agent_crash("legacy sl_finalize_report", e, report)
        return arts
    mod.sl_run_agents = sl_run_agents

    old_summary = getattr(mod, "project_summary", None)
    def project_summary(reports, meta):
        summary = old_summary(reports, meta) if old_summary else {"flags": [], "artifacts": []}
        artifacts = summary.get("artifacts", []) or []
        lane = summary.get("sloper57_review_lanes", {}) or summary.get("sloper56_review_lanes", {}) or summary.get("sloper55_review_lanes", {}) or {}
        lane["v72_zero_width"] = len([a for a in artifacts if "zero_width" in a.get("name", "") or "zero_width" in a.get("kind", "")])
        lane["v72_whitespace_bits"] = len([a for a in artifacts if "whitespace_bits" in a.get("name", "") or "whitespace_bits" in a.get("kind", "")])
        lane["v72_agent_crashes"] = len(AGENT_HEALTH)
        summary["sloper72_review_lanes"] = lane
        summary["sloper72_agent_health"] = AGENT_HEALTH[-100:]
        summary["sloper72_artifact_hub"] = compact_hub(summary)
        def pri(a):
            s = int(a.get("score", 0) or 0)
            text = (str(a.get("source", "")) + " " + str(a.get("kind", "")) + " " + str(a.get("name", ""))).lower()
            if "sloper72" in text or "v72" in text:
                s += 16000
            if "zero_width" in text or "whitespace_bits" in text:
                s += 2500
            return (bool(a.get("exists", False)), s, int(a.get("size", 0) or 0))
        summary["artifacts"] = sorted(artifacts, key=pri, reverse=True)[:8000]
        return summary
    mod.project_summary = project_summary

    try:
        @mod.app.get("/api/artifact_hub/{pid}")
        def artifact_hub(pid: str):
            rep = mod.jread(mod.report_path(pid), {})
            return compact_hub(rep.get("summary", {}))
    except Exception:
        pass

    def _inside_base(path: Path) -> bool:
        try:
            base = Path(getattr(mod, "BASE", Path("."))).resolve()
            rp = path.resolve()
            return rp == base or base in rp.parents
        except Exception:
            return False

    def _report(pid: str):
        try:
            return mod.jread(mod.report_path(pid), {}) or {}
        except Exception:
            return {}

    def _compact_report(pid: str):
        root = mod.pdir(pid)
        meta = mod.jread(mod.meta_path(pid), {}) if root.exists() else {"id": pid, "title": pid}
        rep = _report(pid)
        summary = dict(rep.get("summary", {}) or {})
        artifacts = [a for a in summary.get("artifacts", []) or [] if isinstance(a, dict)]
        priority = [a for a in (summary.get("final_open_queue") or summary.get("priority_artifacts") or []) if isinstance(a, dict)]
        summary["artifact_count"] = len(artifacts)
        summary["artifacts"] = artifacts[:80]
        summary["final_open_queue"] = priority[:80]
        summary["priority_artifacts"] = priority[:80]
        files = []
        for r in rep.get("files", []) or []:
            if not isinstance(r, dict):
                continue
            files.append({
                "name": r.get("name"),
                "rel": r.get("rel"),
                "path": r.get("path"),
                "kind": r.get("kind"),
                "size": r.get("size"),
                "flags": r.get("flags", [])[:8] if isinstance(r.get("flags", []), list) else [],
                "artifact_count": len(r.get("artifacts", []) or []) + len(r.get("transformations", []) or []),
                "error": r.get("error"),
            })
        try:
            job = dict(mod.JOBS.get(pid, {}))
        except Exception:
            job = {}
        return {"project": meta, "job": job, "report": {"summary": summary, "files": files, "updated": rep.get("updated")}}

    try:
        @mod.app.get("/api/projects_compact")
        def projects_compact():
            items = []
            for p in sorted(mod.PROJECTS.iterdir(), key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True):
                if not p.is_dir():
                    continue
                meta = mod.jread(mod.meta_path(p.name), {}) or {"id": p.name, "title": p.name}
                rep = _report(p.name)
                summary = rep.get("summary", {}) or {}
                items.append({
                    "id": p.name,
                    "title": meta.get("title") or meta.get("name") or p.name,
                    "category": meta.get("category", ""),
                    "status": (mod.JOBS.get(p.name, {}) or {}).get("status", "idle") if hasattr(mod, "JOBS") else "idle",
                    "flags": len(summary.get("flags", []) or []),
                    "artifacts": len(summary.get("artifacts", []) or []),
                    "files": len(rep.get("files", []) or []),
                    "updated": rep.get("updated") or meta.get("created"),
                })
            return {"projects": items}

        @mod.app.get("/api/projects/{pid}/compact")
        def project_compact(pid: str):
            return _compact_report(pid)

        @mod.app.get("/api/projects/{pid}/artifacts")
        def project_artifacts(pid: str, offset: int = 0, limit: int = 100, query: str = "", family: str = "", file: str = "", kind: str = "", sort: str = "score"):
            rep = _report(pid)
            summary = rep.get("summary", {}) or {}
            arts = [a for a in summary.get("artifacts", []) or [] if isinstance(a, dict)]
            q = (query or "").lower()
            def match(a):
                blob = (str(a.get("name", "")) + " " + str(a.get("kind", "")) + " " + str(a.get("note", "")) + " " + str(a.get("file", ""))).lower()
                return (not q or q in blob) and (not family or family.lower() in blob) and (not file or file.lower() in str(a.get("file", "")).lower()) and (not kind or kind.lower() in str(a.get("kind", "")).lower())
            arts = [a for a in arts if match(a)]
            if sort == "size":
                arts.sort(key=lambda a: int(a.get("size", 0) or 0), reverse=True)
            elif sort == "name":
                arts.sort(key=lambda a: str(a.get("name", "")).lower())
            else:
                arts.sort(key=lambda a: int(a.get("score", 0) or 0), reverse=True)
            offset = max(0, int(offset or 0)); limit = max(1, min(500, int(limit or 100)))
            return {"total": len(arts), "offset": offset, "limit": limit, "artifacts": arts[offset:offset + limit]}

        @mod.app.get("/api/projects/{pid}/files")
        def project_files(pid: str):
            root = mod.pdir(pid)
            uploaded = []
            try:
                for p in (root / "files").rglob("*"):
                    if p.is_file():
                        uploaded.append({"name": p.name, "path": str(p), "rel": str(p.relative_to(root)), "size": p.stat().st_size, "kind": "file"})
            except Exception:
                pass
            return {"files": uploaded}

        @mod.app.get("/api/projects/{pid}/log")
        def project_log(pid: str, tail: int = 30000):
            root = mod.pdir(pid)
            candidates = [root / "project.log", root / "log.txt", root / "autosolve.log"]
            text = ""
            for p in candidates:
                if p.exists():
                    text = p.read_text(encoding="utf-8", errors="replace")
                    break
            return {"tail": text[-max(1000, min(200000, int(tail or 30000))):], "size": len(text)}

        @mod.app.get("/api/raw_info")
        def raw_info(path: str):
            p = Path(path)
            ok = p.exists() and p.is_file() and _inside_base(p)
            mime, _enc = mimetypes.guess_type(str(p))
            return {"exists": bool(ok), "size": p.stat().st_size if ok else 0, "mime": mime or "application/octet-stream", "kind": (mime or "binary").split("/", 1)[0], "basename": p.name, "url": "/api/raw?path=" + str(p) if ok else ""}

        @mod.app.get("/api/projects/{pid}/artifact_preview")
        def artifact_preview(pid: str, path: str):
            p = Path(path)
            if not (p.exists() and p.is_file() and _inside_base(p)):
                return {"ok": False, "error": "missing or outside project", "path": path}
            data = p.read_bytes()[:65536]
            mime, _enc = mimetypes.guess_type(str(p))
            info = {"ok": True, "path": str(p), "name": p.name, "size": p.stat().st_size, "mime": mime or "application/octet-stream", "raw_url": "/api/raw?path=" + str(p)}
            if (mime or "").startswith("image/"):
                info["kind"] = "image"
            else:
                txt = data.decode("utf-8", "replace")
                info["kind"] = "text" if "\x00" not in txt[:1000] else "binary"
                info["text"] = txt[:20000]
                info["hex_head"] = data[:256].hex(" ")
            return info

        @mod.app.get("/api/projects/{pid}/file_preview")
        def file_preview(pid: str, path: str):
            return artifact_preview(pid, path)
    except Exception as e:
        agent_crash("install compact/raw endpoints", e, None)

    try:
        @mod.app.post("/api/projects/{pid}/stop")
        def stop_project(pid: str):
            try:
                with mod.LOCK:
                    job = mod.JOBS.setdefault(pid, {})
                    job["cancel_requested"] = True
                    job["status"] = "cancelled"
                    job["stage"] = "Stop requested"
                    job["updated"] = mod.time.time()
                try:
                    mod.log(pid, "Stop requested by user")
                except Exception:
                    pass
                return {"ok": True, "status": "cancelled", "pid": pid}
            except Exception as e:
                agent_crash("api stop_project", e, None)
                return {"ok": False, "error": repr(e), "pid": pid}
    except Exception:
        pass

    try:
        from .workflow_v74 import install as install_v74_workflow
        install_v74_workflow(mod)
    except Exception as e:
        agent_crash('install_v74_workflow', e, None)
    try:
        from .workflow_v75 import install as install_v75_logic
        install_v75_logic(mod)
    except Exception as e:
        agent_crash('install_v75_logic', e, None)
    try:
        from .semantic_v76 import install as install_v76_semantic
        install_v76_semantic(mod)
    except Exception as e:
        agent_crash('install_v76_semantic', e, None)
    try:
        from .strict_wraps_v77 import install as install_v77_strict_wraps
        install_v77_strict_wraps(mod)
    except Exception as e:
        agent_crash('install_v77_strict_wraps', e, None)

    try:
        from .universal_v89 import install as install_v89_universal
        install_v89_universal(mod)
    except Exception as e:
        agent_crash('install_v89_universal', e, None)
    try:
        from .v93_reasoned import install as install_v93_reasoned
        install_v93_reasoned(mod)
    except Exception as e:
        agent_crash('install_v93_reasoned', e, None)
    try:
        from .v100_ctf_player import install as install_v100_ctf_player
        install_v100_ctf_player(mod)
    except Exception as e:
        agent_crash('install_v100_ctf_player', e, None)
    try:
        from .final_engine import install as install_final_engine
        install_final_engine(mod)
    except Exception as e:
        agent_crash('install_final_engine', e, None)
    return mod

def boot():
    legacy = importlib.import_module("sloper_legacy")
    install(legacy)
    return legacy
